import json
import requests

# Python3:
try:
    from urllib.parse import urlencode
# Python2:
except ImportError:
    from urllib import urlencode

class HDBApi:
    url_base = None
    share_protocol = 'SMB'
    username = None
    api_key = None

    def __init__(self, url_base, username, api_key, share_protocol = 'SMB'):
        self.url_base = url_base
        self.username = username
        self.api_key = api_key
        self.share_protocol = share_protocol

    def get_json(self, partial_url, request_get_args=None):
        complete_url = "%s%s" % (
            self.url_base, 
            partial_url,
        )

        if request_get_args:
            complete_url = "%s?%s" % (
                complete_url,
                urlencode(request_get_args)
            )
        
        # print("[homodaba] url: %s" % complete_url)

        response = requests.get(complete_url, headers={
            'Authorization': 'Basic %s:%s' % (
                self.username,
                self.api_key
            )
        })

        if response.ok:
            # print("[homodaba] response:")
            # print(response.text)
            return response.json()
        else:
            print("[homodaba] Error '%s' al obtener datos de '%s'." % (response.status_code, complete_url))
            print(response.text)

        return None

    def get_categories(self):
        data = self.get_json("/kodi/json/tags")

        return data["tags"] if data and 'tags' in data else []

    def search_videos(self, query=None, tag=None):
        request_get_args = {
            'protocol': self.share_protocol,
        }

        if tag:
            request_get_args['tag'] = tag
        
        if query:
            request_get_args['query'] = query

        data = self.get_json("/kodi/json/movie/search", request_get_args)

        return data["results"] if data and 'results' in data else []
    
    def last_movies(self):
        request_get_args = {
            'protocol': self.share_protocol,
        }

        data = self.get_json("/kodi/json/movie/last", request_get_args)

        return data["results"] if data and 'results' in data else []
