v1.0.4 (2021-08-20)
  - Moviendo el obsoleto resources/changelog.txt a resources/changelog.md

v1.0.3 (2021-08-19)
  - Fallo en la importacion para leia

v1.0.2 (2021-08-19)
  - Refactorizacion, sacando funcionalidades de la api de HDB
  - Limpiando y ordenando codigo
  - Busqueda por texto libre
  - Listado de ultimas pelis añadidas

v1.0.1 (2021-08-16)
  - Prueba de cambio de version para repo

v1.0.0 (2021-08-11)
  - init, ejemplo con navegacion por cats
